function makeNegative(num) {
  // Code?
  if (num > 0) {
    console.log(Number("-" + num));
  } else {
    console.log(num);
  }
}

let a = 5;
makeNegative(a);
